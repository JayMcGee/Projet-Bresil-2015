/* 
 * File:   GSM.h
 * Author: nitro
 *
 * Created on 29 mai 2014, 09:48
 */

#ifndef GSM_H
#define	GSM_H


#include "commun.h"

void sendGSM();
void POST();
void GET();
void sendJsonDO();
void startGSM();
void CloseGSM();
int STrLengh();

#endif	/* GSM_H */

