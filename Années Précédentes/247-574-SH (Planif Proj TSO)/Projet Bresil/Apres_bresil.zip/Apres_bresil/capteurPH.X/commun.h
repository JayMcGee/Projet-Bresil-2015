#ifndef COMMUN_H
#define COMMUN_H

#include <xc.h>
#include <stdbool.h>       /* For true/false definition */
#include <plib/usart.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <plib/adc.h>
#include "configuration_bits.c"
#include <plib/rtcc.h>
#include <plib/dpslp.h>

#include "usart.h"
#include "bufferint.h"

#define _XTAL_FREQ 4000000
#define USE_AND_MASKS

#define nbchar  10
#define cr      0x0D
#define sContinuousR 0x63
#define sOneR 0x72
#define sStopR 0x65
#define nbcaractValue 10
#define capteurOn "ON \r"
#define capteurOff "OFF \r"


/**
 *
 * @brief Fonction contenant les configurations de depart des differents registres
 *
 */
void commun_initialisationRegistres(void);
/*
 * @brief Fonction utilitaire pour permettre d'avoir des delais > 500 msec
 * @param ms valeur en ms du delai voulu (precision au 10 msec)
 */
void commun_delaiMS(unsigned int ms);

bool Vq = false;
bool Vh = false;
bool dATactif = false;
bool receivedValueCR = false;
int compteID  = 0;
int simultime = 0;
int nbValueToSend = 0 ;
int valuTestCheckSum = 0;
char orderReceived = '\0';
unsigned char receivedValue[nbcaractValue] = "\0";
unsigned char simultimeC[nbcaractValue] = "\0";

 struct FrameReceived
{
    int receivedDataTimePH;
    unsigned char receivedFramePH[5];
}my_FrameReceived[24];

#endif