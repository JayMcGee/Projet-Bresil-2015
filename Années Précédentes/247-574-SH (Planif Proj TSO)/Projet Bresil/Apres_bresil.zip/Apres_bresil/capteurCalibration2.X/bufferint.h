/* 
 * File:   bufferint.h
 * Author: nitro
 *
 * Created on 29 mai 2014, 09:43
 */

#ifndef BUFFERINT_H
#define	BUFFERINT_H


#include "commun.h"


void readbuffer();

#endif	/* BUFFERINT_H */

