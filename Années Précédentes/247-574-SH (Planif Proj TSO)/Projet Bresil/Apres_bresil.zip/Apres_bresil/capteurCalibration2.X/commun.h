#ifndef COMMUN_H
#define COMMUN_H

#include <xc.h>
#include <stdbool.h>       /* For true/false definition */
#include <plib/usart.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <plib/adc.h>
#include "configuration_bits.c"
#include <plib/rtcc.h>
#include <plib/dpslp.h>

#include "bufferint.h"

#define _XTAL_FREQ 4000000
#define USE_AND_MASKS
#define SOH 0x01
#define nbchar  10
#define cr      0x0D
#define sContinuousR 0x63
#define sStopR 0x65

#define capteurOn "ON \r"
#define capteurOff "OFF \r"
/**
 *
 * @brief Fonction contenant les configurations de depart des differents registres
 *
 */
void commun_initialisationRegistres(void);
/**
 * @brief Fonction utilitaire pour permettre d'avoir des delais > 500 msec
 * @param ms valeur en ms du delai voulu (precision au 10 msec)
 */
void commun_delaiMS(unsigned int ms);

int buffer1Read = 0 ;
int buffer1Write = 0;
int buffer2Read = 0 ;
int buffer2Write = 0;
unsigned char bufferint1[128];
unsigned char bufferint2[128];

bool dATactif = false;
bool receivedValueCR = false;
char orderReceived = '\0';
unsigned char receivedValue[10] = "\0";
unsigned char simultimeC[10] = "\0";

 struct VAL
{
    unsigned char simultimeVAL[10];
    unsigned char receivedValueVAL[10];
}my_VAL[24];

#endif