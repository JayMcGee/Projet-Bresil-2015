#include "bufferint.h"

void readbuffer()
{
    char br1 = '\0';
    char br2 = '\0';
    if(buffer1Write != buffer1Read)
    {
        buffer1Read  ++;

        if(buffer1Read>= 128)
        {
           buffer1Read = 0;
        }
        br1 = bufferint1[buffer1Read];
//        while(Busy2USART());
//        Write2USART(br1);
       switch(br1) // valeur ASCII du caractere appuye
        {
            case SOH: // touche DEL
                VSOH = true;
                break;
            case SOL: // touche DEL
                if(VSOH)
                {
                    VSOH = false;
                    VSOok = 1;
                    nbOfChar = 0;
                }
                break;
            default:
                    if(VSOok == 1)
                    {
                        checksumtoChesck = 0;
                        dataLenghtoReceived = (int)br1 <<8;
                        VSOok = 2;
                    }
                    else if(VSOok == 2)
                    {
                        dataLenghtoReceived += (int)br1 & 0x0FF;
                        VSOok = 3;
                    }
                    else if(VSOok == 3)
                    {
                        idReceived = (int)br1;
                        checksumtoChesck = (int)br1;
                        nbOfChar = 0;
                        VSOok = 4;
                    }
                    else if(VSOok == 4)
                    {
                        if(nbOfChar<=dataLenghtoReceived-2)
                        {
                            trameToParse[nbOfChar] = br1;
                            checksumtoChesck += (int)br1;
                        }
                        else
                        {
                            trameToParse[nbOfChar] = br1;
                            checksumtoChesck += (int)br1;
                            VSOok = 5;
                        }
                        //? pas enctrameToParse[nbOfChar] = br1;
                        nbOfChar ++;
                    }
                    else if(VSOok == 5)
                    {

                        ChecksumReceived = br1 <<8;
                        VSOok = 6;
                    }
                    else if(VSOok == 6)
                    {
                        ChecksumReceived += br1 & 0x0FF;
                        VSOok = 0;

                        if(checksumtoChesck == ChecksumReceived)
                        {
                          //  trameToParse[0] = '\0';
                            VtrameReceived = true;
                        }
                        else
                        {
                            trameToParse[0] = '\0';
                            idReceived = 0;
                            VtrameReceived = false;
                        }

                    }

                break;
        };
    }
    else if(buffer2Write != buffer2Read)
    {
        buffer2Read  ++;
        if(buffer2Read>= 128)
        {
           buffer2Read = 0;
        }
        br2 = bufferint2[buffer2Read];
//        while(Busy1USART());
//        Write1USART(br2);
        
        if(br2 == cr )
        {
            receivedValueCR = true;
        }
        else
        {
            receivedValue[compteID] = br2;
            compteID++;
        }
    }
}
void executeBuffer()
{
   // int w=0;
    
    if(idReceived == 0x20)
    {
     //   w=0;
        //future inserer la fonction de reset du timer
        idReceived = 0;
    }
    else if(idReceived == 0x21)
    {
        int testtt = 0;
        switch(trameToParse[0]) // valeur ASCII du caractere appuye
        {
            case 'p': // touche DEL
                if(VpowerSensor)
                {
                    PORTCbits.RC3 = 1;
                    while(Busy1USART());
                    Write1USART('1');
                    VpowerSensor=false;
                }
                else
                {
                    PORTCbits.RC3 = 0;
                    while(Busy1USART());
                    Write1USART('0');
                    VpowerSensor=true;
                }
                break;
            case 'd':  //Start continuous reading of sensor (send c<cr>)
                orderReceived = '\0';
                while(Busy2USART());
                Write2USART(sContinuousR);
                while(Busy2USART());
                Write2USART(cr);
                while(Busy1USART());
                Write1USART(sContinuousR);
                while(Busy1USART());
                Write1USART(cr);
                break;
            case 'e': //Stop reading of sensor (send e<cr>)
                orderReceived = '\0';
                while(Busy2USART());
                Write2USART(sStopR);
                while(Busy2USART());
                Write2USART(cr);
                while(Busy1USART());
                Write1USART(sStopR);
                while(Busy1USART());
                Write1USART(cr);
                break;
            case 'b': //Stop reading of sensor (send e<cr>)
                orderReceived = '\0';
                while(Busy2USART());
                Write2USART(sOneR);
                while(Busy2USART());
                Write2USART(cr);
                while(Busy1USART());
                Write1USART(sOneR);
                while(Busy1USART());
                Write1USART(cr);
                break;
            case 'q':
                Vq = true;                
                break;
            case 'l':
                Vh = true;
                
                break;
            default:
                break;

        };

        idReceived = 0;
    }

    

}
