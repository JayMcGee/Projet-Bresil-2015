/*
 * File:   main.c
 * Author: Maxime
 *
 * Created on 7 f�vrier 2014, 11:49
 */
#include "commun.h"
/*
 *
 */
void usartConfig();
void usartConfig2AT9600();
/*
 *
 */
unsigned char dep[10] = "depart \r";
unsigned char don[25]= "capteur calibration\r";
/*
*
*/
int main(int argc, char** argv)
{
    commun_initialisationRegistres();
    usartConfig();
    usartConfig2AT9600();
    puts1USART(dep);
    puts1USART(don);

    while(1)
    {
        if(buffer1Write == buffer1Read && buffer2Write == buffer2Read)
        {
            switch(orderReceived) // valeur ASCII du caractere appuye
            {
                case '1':  //Start continuous reading of sensor (send c<cr>)
                    orderReceived = '\0';
                    usartConfig2AT9600();
                    break;
                case '2': //Stop reading of sensor (send e<cr>)
                    break;
                default:
                    break;
            }
        }
        else
        {
            readbuffer();
        }

        

    }
    return (EXIT_SUCCESS);
}
//For init USART1 (at pin RX1 1 and TX1 44)
void usartConfig()
{
    unsigned char USART1config = 0;
    unsigned char baudRate = 25;   //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    TRISCbits.TRISC6= 0; //TX output
    TRISCbits.TRISC7 = 1; //RX input
    USART1config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open1USART(USART1config,baudRate); //Open EUSART and set the parameter
}
//For init USART1 (at pin RX1 15 and TX1 14)
void usartConfig2AT9600()
{
    unsigned char USART2config = 0;
    unsigned char baudRate = 25;//il ne faut pas oublier de configurer le board de covertion
    //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    PPSCON = 0x00;
    RPINR16 = 0x07;//pin RX1 15
    RPOR8 = 0x06;  //pin TX1 14
    PPSCON = 0x01;
   // ANCON0bits.PCFG0 = 1;
    USART2config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open2USART(USART2config,baudRate); //Open EUSART and set the parameter
}





