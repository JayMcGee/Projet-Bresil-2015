﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace interface_usager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            int colonne = 5, range = 11;
            for (int j = 0; j < range; j++) // Les rangées 
            {
                tableauDeDonnee.Rows.Add();

                for (int i = 0; i < colonne; i++) // Les cellules des rangées 
                {

                    tableauDeDonnee.Rows[j].Cells[i].Value = "Valeur";
                }
            }
            range = 0;
        }

        private void ltemperature_Click(object sender, EventArgs e)
        {

        }

        private void lvent_Click(object sender, EventArgs e)
        {

        }

        private void tableauDeDonnee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
