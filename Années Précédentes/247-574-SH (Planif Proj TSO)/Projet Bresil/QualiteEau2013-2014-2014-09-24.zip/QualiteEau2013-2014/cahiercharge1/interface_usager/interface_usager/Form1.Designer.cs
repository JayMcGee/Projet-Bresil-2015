﻿namespace interface_usager
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableauDeDonnee = new System.Windows.Forms.DataGridView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btConfig = new System.Windows.Forms.ToolStripButton();
            this.btouvrePort = new System.Windows.Forms.ToolStripButton();
            this.btfermePort = new System.Windows.Forms.ToolStripButton();
            this.btsauvegardeDonne = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.textPortSerie = new System.Windows.Forms.ToolStripStatusLabel();
            this.statutPort = new System.Windows.Forms.ToolStripStatusLabel();
            this.etatPort = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tpressionFract = new System.Windows.Forms.TrackBar();
            this.tpressionInt = new System.Windows.Forms.TrackBar();
            this.tbpressionInt = new System.Windows.Forms.TextBox();
            this.tbpressionFract = new System.Windows.Forms.TextBox();
            this.lpressionFract = new System.Windows.Forms.Label();
            this.lpression = new System.Windows.Forms.Label();
            this.lpressionInt = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lvent = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lhumidite = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ttempFract = new System.Windows.Forms.TrackBar();
            this.ttempInt = new System.Windows.Forms.TrackBar();
            this.tbtempFract = new System.Windows.Forms.TextBox();
            this.tbtempInt = new System.Windows.Forms.TextBox();
            this.ltempFract = new System.Windows.Forms.Label();
            this.ltempInt = new System.Windows.Forms.Label();
            this.ltemperature = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgTemps = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTemperature = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgHumditie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgVitesse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDirection = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tableauDeDonnee)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tpressionFract)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tpressionInt)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttempFract)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttempInt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            this.SuspendLayout();
            // 
            // tableauDeDonnee
            // 
            this.tableauDeDonnee.AllowUserToOrderColumns = true;
            this.tableauDeDonnee.BackgroundColor = System.Drawing.Color.Black;
            this.tableauDeDonnee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableauDeDonnee.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgTemps,
            this.dgTemperature,
            this.dgHumditie,
            this.dgVitesse,
            this.dgDirection});
            this.tableauDeDonnee.Location = new System.Drawing.Point(12, 215);
            this.tableauDeDonnee.Name = "tableauDeDonnee";
            this.tableauDeDonnee.Size = new System.Drawing.Size(556, 268);
            this.tableauDeDonnee.TabIndex = 13;
            this.tableauDeDonnee.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tableauDeDonnee_CellContentClick);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btConfig,
            this.btouvrePort,
            this.btfermePort,
            this.btsauvegardeDonne});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(664, 25);
            this.toolStrip1.TabIndex = 12;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btConfig
            // 
            this.btConfig.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btConfig.Image = ((System.Drawing.Image)(resources.GetObject("btConfig.Image")));
            this.btConfig.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btConfig.Name = "btConfig";
            this.btConfig.Size = new System.Drawing.Size(23, 22);
            this.btConfig.Text = "toolStripButton1";
            // 
            // btouvrePort
            // 
            this.btouvrePort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btouvrePort.Image = ((System.Drawing.Image)(resources.GetObject("btouvrePort.Image")));
            this.btouvrePort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btouvrePort.Name = "btouvrePort";
            this.btouvrePort.Size = new System.Drawing.Size(23, 22);
            this.btouvrePort.Text = "toolStripButton2";
            // 
            // btfermePort
            // 
            this.btfermePort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btfermePort.Image = ((System.Drawing.Image)(resources.GetObject("btfermePort.Image")));
            this.btfermePort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btfermePort.Name = "btfermePort";
            this.btfermePort.Size = new System.Drawing.Size(23, 22);
            this.btfermePort.Text = "toolStripButton3";
            // 
            // btsauvegardeDonne
            // 
            this.btsauvegardeDonne.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btsauvegardeDonne.Image = ((System.Drawing.Image)(resources.GetObject("btsauvegardeDonne.Image")));
            this.btsauvegardeDonne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btsauvegardeDonne.Name = "btsauvegardeDonne";
            this.btsauvegardeDonne.Size = new System.Drawing.Size(23, 22);
            this.btsauvegardeDonne.Text = "toolStripButton4";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textPortSerie,
            this.statutPort,
            this.etatPort});
            this.statusStrip1.Location = new System.Drawing.Point(0, 492);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(664, 22);
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // textPortSerie
            // 
            this.textPortSerie.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textPortSerie.Name = "textPortSerie";
            this.textPortSerie.Size = new System.Drawing.Size(62, 17);
            this.textPortSerie.Text = "Port série :";
            // 
            // statutPort
            // 
            this.statutPort.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statutPort.Name = "statutPort";
            this.statutPort.Size = new System.Drawing.Size(118, 17);
            this.statutPort.Text = "toolStripStatusLabel2";
            // 
            // etatPort
            // 
            this.etatPort.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.etatPort.Name = "etatPort";
            this.etatPort.Size = new System.Drawing.Size(40, 17);
            this.etatPort.Text = "inactif";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Controls.Add(this.tpressionFract);
            this.panel4.Controls.Add(this.tpressionInt);
            this.panel4.Controls.Add(this.tbpressionInt);
            this.panel4.Controls.Add(this.tbpressionFract);
            this.panel4.Controls.Add(this.lpressionFract);
            this.panel4.Controls.Add(this.lpression);
            this.panel4.Controls.Add(this.lpressionInt);
            this.panel4.Location = new System.Drawing.Point(511, 28);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(145, 181);
            this.panel4.TabIndex = 10;
            // 
            // tpressionFract
            // 
            this.tpressionFract.Cursor = System.Windows.Forms.Cursors.Default;
            this.tpressionFract.Location = new System.Drawing.Point(85, 49);
            this.tpressionFract.Maximum = 100;
            this.tpressionFract.Name = "tpressionFract";
            this.tpressionFract.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tpressionFract.Size = new System.Drawing.Size(45, 94);
            this.tpressionFract.TabIndex = 21;
            // 
            // tpressionInt
            // 
            this.tpressionInt.Location = new System.Drawing.Point(20, 49);
            this.tpressionInt.Maximum = 115;
            this.tpressionInt.Minimum = 80;
            this.tpressionInt.Name = "tpressionInt";
            this.tpressionInt.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tpressionInt.Size = new System.Drawing.Size(45, 94);
            this.tpressionInt.TabIndex = 20;
            this.tpressionInt.Value = 80;
            // 
            // tbpressionInt
            // 
            this.tbpressionInt.Location = new System.Drawing.Point(20, 149);
            this.tbpressionInt.Name = "tbpressionInt";
            this.tbpressionInt.Size = new System.Drawing.Size(37, 20);
            this.tbpressionInt.TabIndex = 16;
            // 
            // tbpressionFract
            // 
            this.tbpressionFract.Location = new System.Drawing.Point(85, 149);
            this.tbpressionFract.Name = "tbpressionFract";
            this.tbpressionFract.Size = new System.Drawing.Size(37, 20);
            this.tbpressionFract.TabIndex = 17;
            // 
            // lpressionFract
            // 
            this.lpressionFract.AutoSize = true;
            this.lpressionFract.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lpressionFract.ForeColor = System.Drawing.Color.MediumBlue;
            this.lpressionFract.Location = new System.Drawing.Point(62, 29);
            this.lpressionFract.Name = "lpressionFract";
            this.lpressionFract.Size = new System.Drawing.Size(73, 17);
            this.lpressionFract.TabIndex = 10;
            this.lpressionFract.Text = "Fraction";
            // 
            // lpression
            // 
            this.lpression.AutoSize = true;
            this.lpression.Font = new System.Drawing.Font("Showcard Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lpression.ForeColor = System.Drawing.Color.MediumBlue;
            this.lpression.Location = new System.Drawing.Point(37, 9);
            this.lpression.Name = "lpression";
            this.lpression.Size = new System.Drawing.Size(57, 20);
            this.lpression.TabIndex = 5;
            this.lpression.Text = "Le PH";
            // 
            // lpressionInt
            // 
            this.lpressionInt.AutoSize = true;
            this.lpressionInt.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lpressionInt.ForeColor = System.Drawing.Color.MediumBlue;
            this.lpressionInt.Location = new System.Drawing.Point(3, 29);
            this.lpressionInt.Name = "lpressionInt";
            this.lpressionInt.Size = new System.Drawing.Size(54, 17);
            this.lpressionInt.TabIndex = 9;
            this.lpressionInt.Text = "Entier";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.trackBar1);
            this.panel3.Controls.Add(this.trackBar2);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.lvent);
            this.panel3.Location = new System.Drawing.Point(355, 28);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(145, 181);
            this.panel3.TabIndex = 9;
            // 
            // lvent
            // 
            this.lvent.AutoSize = true;
            this.lvent.Font = new System.Drawing.Font("Showcard Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvent.ForeColor = System.Drawing.Color.MediumBlue;
            this.lvent.Location = new System.Drawing.Point(3, 9);
            this.lvent.Name = "lvent";
            this.lvent.Size = new System.Drawing.Size(139, 20);
            this.lvent.TabIndex = 6;
            this.lvent.Text = "Conductivité";
            this.lvent.Click += new System.EventHandler(this.lvent_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.trackBar3);
            this.panel2.Controls.Add(this.trackBar4);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lhumidite);
            this.panel2.Location = new System.Drawing.Point(163, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 181);
            this.panel2.TabIndex = 8;
            // 
            // lhumidite
            // 
            this.lhumidite.AutoSize = true;
            this.lhumidite.Font = new System.Drawing.Font("Showcard Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lhumidite.ForeColor = System.Drawing.Color.MediumBlue;
            this.lhumidite.Location = new System.Drawing.Point(2, 9);
            this.lhumidite.Name = "lhumidite";
            this.lhumidite.Size = new System.Drawing.Size(183, 20);
            this.lhumidite.TabIndex = 7;
            this.lhumidite.Text = " L\'oxigène dissous";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.ttempFract);
            this.panel1.Controls.Add(this.ttempInt);
            this.panel1.Controls.Add(this.tbtempFract);
            this.panel1.Controls.Add(this.tbtempInt);
            this.panel1.Controls.Add(this.ltempFract);
            this.panel1.Controls.Add(this.ltempInt);
            this.panel1.Controls.Add(this.ltemperature);
            this.panel1.Location = new System.Drawing.Point(12, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(145, 181);
            this.panel1.TabIndex = 7;
            // 
            // ttempFract
            // 
            this.ttempFract.Location = new System.Drawing.Point(82, 49);
            this.ttempFract.Maximum = 100;
            this.ttempFract.Name = "ttempFract";
            this.ttempFract.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.ttempFract.Size = new System.Drawing.Size(45, 94);
            this.ttempFract.TabIndex = 19;
            // 
            // ttempInt
            // 
            this.ttempInt.Location = new System.Drawing.Point(20, 49);
            this.ttempInt.Maximum = 50;
            this.ttempInt.Minimum = -50;
            this.ttempInt.Name = "ttempInt";
            this.ttempInt.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.ttempInt.Size = new System.Drawing.Size(45, 94);
            this.ttempInt.TabIndex = 18;
            // 
            // tbtempFract
            // 
            this.tbtempFract.Location = new System.Drawing.Point(82, 149);
            this.tbtempFract.Name = "tbtempFract";
            this.tbtempFract.Size = new System.Drawing.Size(37, 20);
            this.tbtempFract.TabIndex = 13;
            // 
            // tbtempInt
            // 
            this.tbtempInt.Location = new System.Drawing.Point(20, 149);
            this.tbtempInt.Name = "tbtempInt";
            this.tbtempInt.Size = new System.Drawing.Size(37, 20);
            this.tbtempInt.TabIndex = 12;
            // 
            // ltempFract
            // 
            this.ltempFract.AutoSize = true;
            this.ltempFract.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltempFract.ForeColor = System.Drawing.Color.MediumBlue;
            this.ltempFract.Location = new System.Drawing.Point(62, 29);
            this.ltempFract.Name = "ltempFract";
            this.ltempFract.Size = new System.Drawing.Size(73, 17);
            this.ltempFract.TabIndex = 8;
            this.ltempFract.Text = "Fraction";
            // 
            // ltempInt
            // 
            this.ltempInt.AutoSize = true;
            this.ltempInt.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltempInt.ForeColor = System.Drawing.Color.MediumBlue;
            this.ltempInt.Location = new System.Drawing.Point(5, 29);
            this.ltempInt.Name = "ltempInt";
            this.ltempInt.Size = new System.Drawing.Size(54, 17);
            this.ltempInt.TabIndex = 7;
            this.ltempInt.Text = "Entier";
            // 
            // ltemperature
            // 
            this.ltemperature.AutoSize = true;
            this.ltemperature.Font = new System.Drawing.Font("Showcard Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltemperature.ForeColor = System.Drawing.Color.MediumBlue;
            this.ltemperature.Location = new System.Drawing.Point(2, 9);
            this.ltemperature.Name = "ltemperature";
            this.ltemperature.Size = new System.Drawing.Size(136, 20);
            this.ltemperature.TabIndex = 4;
            this.ltemperature.Text = "Température";
            this.ltemperature.Click += new System.EventHandler(this.ltemperature_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(84, 49);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(45, 94);
            this.trackBar1.TabIndex = 25;
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(22, 49);
            this.trackBar2.Maximum = 50;
            this.trackBar2.Minimum = -50;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar2.Size = new System.Drawing.Size(45, 94);
            this.trackBar2.TabIndex = 24;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(84, 149);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(37, 20);
            this.textBox1.TabIndex = 23;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(22, 149);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(37, 20);
            this.textBox2.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumBlue;
            this.label1.Location = new System.Drawing.Point(64, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Fraction";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumBlue;
            this.label2.Location = new System.Drawing.Point(7, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Entier";
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(104, 49);
            this.trackBar3.Maximum = 100;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar3.Size = new System.Drawing.Size(45, 94);
            this.trackBar3.TabIndex = 25;
            // 
            // trackBar4
            // 
            this.trackBar4.Location = new System.Drawing.Point(42, 49);
            this.trackBar4.Maximum = 50;
            this.trackBar4.Minimum = -50;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar4.Size = new System.Drawing.Size(45, 94);
            this.trackBar4.TabIndex = 24;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(104, 149);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(37, 20);
            this.textBox3.TabIndex = 23;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(42, 149);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(37, 20);
            this.textBox4.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(84, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 21;
            this.label3.Text = "Fraction";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MediumBlue;
            this.label4.Location = new System.Drawing.Point(27, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "Entier";
            // 
            // dgTemps
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgTemps.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgTemps.HeaderText = "Temps";
            this.dgTemps.Name = "dgTemps";
            this.dgTemps.ReadOnly = true;
            // 
            // dgTemperature
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgTemperature.DefaultCellStyle = dataGridViewCellStyle12;
            this.dgTemperature.HeaderText = "Température (deg C)";
            this.dgTemperature.Name = "dgTemperature";
            this.dgTemperature.ReadOnly = true;
            // 
            // dgHumditie
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgHumditie.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgHumditie.HeaderText = "L\'oxigène dissous";
            this.dgHumditie.Name = "dgHumditie";
            this.dgHumditie.ReadOnly = true;
            // 
            // dgVitesse
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgVitesse.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgVitesse.HeaderText = " Conductivité";
            this.dgVitesse.Name = "dgVitesse";
            this.dgVitesse.ReadOnly = true;
            // 
            // dgDirection
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgDirection.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgDirection.HeaderText = "Le PH";
            this.dgDirection.Name = "dgDirection";
            this.dgDirection.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 514);
            this.Controls.Add(this.tableauDeDonnee);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.tableauDeDonnee)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tpressionFract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tpressionInt)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttempFract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttempInt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView tableauDeDonnee;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btConfig;
        private System.Windows.Forms.ToolStripButton btouvrePort;
        private System.Windows.Forms.ToolStripButton btfermePort;
        private System.Windows.Forms.ToolStripButton btsauvegardeDonne;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel textPortSerie;
        private System.Windows.Forms.ToolStripStatusLabel statutPort;
        private System.Windows.Forms.ToolStripStatusLabel etatPort;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TrackBar tpressionFract;
        private System.Windows.Forms.TrackBar tpressionInt;
        private System.Windows.Forms.TextBox tbpressionInt;
        private System.Windows.Forms.TextBox tbpressionFract;
        private System.Windows.Forms.Label lpressionFract;
        private System.Windows.Forms.Label lpression;
        private System.Windows.Forms.Label lpressionInt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lvent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lhumidite;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TrackBar ttempFract;
        private System.Windows.Forms.TrackBar ttempInt;
        private System.Windows.Forms.TextBox tbtempFract;
        private System.Windows.Forms.TextBox tbtempInt;
        private System.Windows.Forms.Label ltempFract;
        private System.Windows.Forms.Label ltempInt;
        private System.Windows.Forms.Label ltemperature;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTemps;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTemperature;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgHumditie;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgVitesse;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDirection;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.TrackBar trackBar4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

