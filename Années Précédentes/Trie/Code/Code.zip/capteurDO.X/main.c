/*
 * File:   main.c
 * Author: Maxime
 *
 * Created on 7 f�vrier 2014, 11:49
 */
#include "commun.h"
/*
 *
 */
void usartConfig();
void usartConfig2();
void dort();
//void SendSerieTeste();
void ClearMemory();
void comUSART();
void receivedValueSensor();
extern int lireadc6(void);
/*
 *
 */
unsigned char dep[15] = "depart DO\r";
/*
*
*/
int main(int argc, char** argv)
{
    commun_initialisationRegistres();
    usartConfig();
    usartConfig2();
    RtccInitClock();
    puts1USART(dep);

    while(1)
    {
      //  writeUsart1Trame(CtoS,0xFFFF,CommandeManuel);
        if(buffer1Write == buffer1Read && buffer2Write == buffer2Read)
        {
            if(VtrameReceived)
            {
               executeBuffer();
               VtrameReceived = false;
            }
            else if(Vq)
            {
                ClearMemory();
                Vq = false;
            }
            else if(Vh)
            {
                orderReceived = '\0';
                comUSART();
                Vh = false;
            }

        }
        else
        {
            readbuffer();
        }

        if(receivedValueCR)
        {
            receivedValueSensor();
        }

    }
    return (EXIT_SUCCESS);
}
//For init USART1 (at pin RX1 1 and TX1 44)
void usartConfig()
{
    unsigned char USART1config = 0;
    unsigned char baudRate = 25;   //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    TRISCbits.TRISC6= 0; //TX output
    TRISCbits.TRISC7 = 1; //RX input
    USART1config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open1USART(USART1config,baudRate); //Open EUSART and set the parameter
}

//For init USART1 (at pin RX1 15 and TX1 14)
void usartConfig2()
{
    unsigned char USART2config = 0;
    unsigned char baudRate = 25;//il ne faut pas oublier de configurer le board de covertion
    //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    PPSCON = 0x00;
    RPINR16 = 0x08;//pin RX1 15
    RPOR7 = 0x06;  //pin TX1 14
    PPSCON = 0x01;
   // ANCON0bits.PCFG0 = 1;
    USART2config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open2USART(USART2config,baudRate); //Open EUSART and set the parameter
}

//void SendSerieTeste()
//{
//    for(int g = 0;g <= nbValueToSend; g++)
//    {
//        puts1USART(my_FrameReceived[g].receivedDataTimeDO);
//        puts1USART(my_FrameReceived[g].receivedFrameDO);
//
//        for(int erase =0;erase<=nbcaractValue-1;erase++)
//        {
//            my_FrameReceived[g].receivedFrameDO[erase] = '\0';
//            my_FrameReceived[g].receivedDataTimeDO[erase] = '\0';
//        }
//    }
//    nbValueToSend = 0 ;
//}

void ClearMemory()
{
    for(int g = 0;g <= nbValueToSend; g++)
    {
        for(int erase =0;erase<=4;erase++)
        {
            my_FrameReceived[g].receivedFrameDO[erase] = '\0';
        }
        my_FrameReceived[g].receivedDataTimeDO = 0;
    }
    nbValueToSend = 0 ;
}
//Pour �crire:
void comUSART()
{
    for(int g = 0;g <= nbValueToSend-1; g++)
    {
        writeUsart1Trame(my_FrameReceived[g].receivedFrameDO,my_FrameReceived[g].receivedDataTimeDO,DO);//(my_FrameReceived[g].receivedDataTimeDO);
        commun_delaiMS(10);
        for(int erase =0;erase<=4;erase++)
        {
            my_FrameReceived[g].receivedFrameDO[erase] = '\0';
        }
        my_FrameReceived[g].receivedDataTimeDO= 0;        
    }
    
    valuTestCheckSum = 0;
    nbValueToSend = 0 ;
}

void receivedValueSensor()
{
    while(Busy1USART());
    Write1USART('#');
    itoa(simultimeC,simultime,16);
    writeUsart1(simultimeC);
    writeUsart1(receivedValue);

    for(int k =0;k<=4;k++)
    {
        if((char)receivedValue[k] != 0x20)
        {
            my_FrameReceived[nbValueToSend].receivedFrameDO[k] = (char)receivedValue[k];
            receivedValue[k] = '\0';
        }
    }
    my_FrameReceived[nbValueToSend].receivedFrameDO[compteID] = '\0';
    my_FrameReceived[nbValueToSend].receivedDataTimeDO = 0;
    my_FrameReceived[nbValueToSend].receivedDataTimeDO = simultime;
        

//    for(int j =0;j<=nbcaractValue-1;j++)
//    {
//        receivedValue[j] = '\0';
//        simultimeC[j] = '\0';
//    }

    compteID  = 0;
    simultime++;
    nbValueToSend++;
    receivedValueCR = false;
}



