#include "bufferint.h"

void readbuffer()
{
    char br1 = '\0';
    char br2 = '\0';

    if(buffer1Write != buffer1Read)
    {
        buffer1Read  ++;
        
        if(buffer1Read>= 128)
        {
           buffer1Read = 0;
        }
        br1 = bufferint1[buffer1Read];
//        while(Busy1USART());
//        Write1USART(bufferint1[buffer1Read]);
        while(Busy2USART());
        Write2USART(br1);


    }
    else if(buffer2Write != buffer2Read)
    {
        buffer2Read  ++;
        if(buffer2Read>= 128)
        {
           buffer2Read = 0;
        }
        br2 = bufferint2[buffer2Read];
        while(Busy1USART());
        Write1USART(br2);
    }
}
