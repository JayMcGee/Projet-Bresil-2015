 /*
 * File:   main.c
 * Author: Maxime
 *
 * Created on 7 f�vrier 2014, 11:49
 */

#include "commun.h"
/*
 *
 */
void usartConfig();
void usartConfig2();
void dort();
void ClearMemory();
void comUSART();
void receivedValueSensor();
extern int lireadc6(void);
/*
 *
 */
unsigned char dep[10] = "departEC\r";
/*
*
*/
int main(int argc, char** argv)
{
    commun_initialisationRegistres();
    usartConfig();
    usartConfig2();
    RtccInitClock();
    puts1USART(dep);

    while(1)
    {
        if(buffer1Write == buffer1Read && buffer2Write == buffer2Read)
        {
            if(receivedValueCR)
            {
                receivedValueSensor();
            }

            if(VtrameReceived)
            {
               executeBuffer();
               VtrameReceived = false;
            }
            else if(Vq)
            {
                ClearMemory();
                Vq = false;
            }
            else if(Vh)
            {
                orderReceived = '\0';
                comUSART();
                Vh = false;
            }

        }
        else
        {
            if(receivedValueCR)
            {
                receivedValueSensor();
            }

            readbuffer();
        }

        if(receivedValueCR)
        {
            receivedValueSensor();
        }

    }
    return (EXIT_SUCCESS);
}
//For init USART1 (at pin RX1 1 and TX1 44)
void usartConfig()
{
    unsigned char USART1config = 0;
    unsigned char baudRate = 25;   //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    TRISCbits.TRISC6= 0; //TX output
    TRISCbits.TRISC7 = 1; //RX input
    USART1config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open1USART(USART1config,baudRate); //Open EUSART and set the parameter
}

//For init USART1 (at pin RX1 15 and TX1 14)
void usartConfig2()
{
    unsigned char USART2config = 0;
    unsigned char baudRate = 25;//il ne faut pas oublier de configurer le board de covertion
    //25 = 9600 Bauds at 4Mhz //103 = 9600 Bauds at 16 Mhz
    //initialise la communication uart
    PPSCON = 0x00;
    RPINR16 = 0x08;//pin RX1 15
    RPOR7 = 0x06;  //pin TX1 14
    PPSCON = 0x01;
   // ANCON0bits.PCFG0 = 1;
    USART2config = USART_TX_INT_OFF & USART_RX_INT_ON &
            USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_BRGH_HIGH;
    Open2USART(USART2config,baudRate); //Open EUSART and set the parameter
}


void ClearMemory()
{
    for(int g = 0;g <= nbValueToSend; g++)
    {
        my_FrameReceived[g].receivedFrameEC[0] = '\0';
        my_FrameReceived[g].receivedFrameEC[1] = '\0';
        my_FrameReceived[g].receivedFrameEC[2] = '\0';
        my_FrameReceived[g].receivedFrameEC[3] = '\0';
        my_FrameReceived[g].receivedFrameEC[4] = '\0';
        my_FrameReceived[g].receivedFrameEC[5] = '\0';
        my_FrameReceived[g].receivedDataTimeEC = 0;
        my_FrameReceived[g].receivedFrameTDS[0] = '\0';
        my_FrameReceived[g].receivedFrameTDS[1] = '\0';
        my_FrameReceived[g].receivedFrameTDS[2] = '\0';
        my_FrameReceived[g].receivedFrameTDS[3] = '\0';
        my_FrameReceived[g].receivedFrameTDS[4] = '\0';
        my_FrameReceived[g].receivedFrameTDS[5] = '\0';
        my_FrameReceived[g].receivedDataTimeTDS = 0;
    }
    nbValueToSend = 0 ;
}
//Pour �crire:
void comUSART()
{
    for(int g = 0;g <= nbValueToSend-1; g++)
    {
        writeUsart1Trame(my_FrameReceived[g].receivedFrameEC,my_FrameReceived[g].receivedDataTimeEC,EC);
        while(Busy1USART());
        Write1USART(cr);

        writeUsart1Trame(my_FrameReceived[g].receivedFrameTDS,my_FrameReceived[g].receivedDataTimeTDS,TDS);
        while(Busy1USART());
        Write1USART(cr);
        
        my_FrameReceived[g].receivedFrameEC[0] = '\0';
        my_FrameReceived[g].receivedFrameEC[1] = '\0';
        my_FrameReceived[g].receivedFrameEC[2] = '\0';
        my_FrameReceived[g].receivedFrameEC[3] = '\0';
        my_FrameReceived[g].receivedFrameEC[4] = '\0';
        my_FrameReceived[g].receivedFrameEC[5] = '\0';
        my_FrameReceived[g].receivedDataTimeEC = 0;        
        my_FrameReceived[g].receivedFrameTDS[0] = '\0';
        my_FrameReceived[g].receivedFrameTDS[1] = '\0';
        my_FrameReceived[g].receivedFrameTDS[2] = '\0';
        my_FrameReceived[g].receivedFrameTDS[3] = '\0';
        my_FrameReceived[g].receivedFrameTDS[4] = '\0';
        my_FrameReceived[g].receivedFrameTDS[5] = '\0';
        my_FrameReceived[g].receivedDataTimeTDS = 0;
    }


    valuTestCheckSum = 0;
    nbValueToSend = 0 ;
}

void receivedValueSensor()
{
    int nbreceivedValue = 0;
    int valueVirgule = 0;
    int valueVirgule2 = 0;
    int nbvirgule = 0;
    int m =0;
    int k =0;
    while(Busy1USART());     
    Write1USART('#');
    itoa(simultimeC,simultime,16);
    writeUsart1(simultimeC);
    writeUsart1(receivedValue);
    for(int d =0;d<=20;d++)
    {
        if((char)receivedValue[d] == ',' && nbvirgule ==1)//
        {
            valueVirgule2 = d;
            nbvirgule = 2;
        }
        if((char)receivedValue[d] == ',' && nbvirgule ==0)//
        {
            valueVirgule = d;
            nbvirgule = 1;
        }        
    }
    nbvirgule = 0;
    for(k =0;k<=valueVirgule+1;k++)
    {
            my_FrameReceived[nbValueToSend].receivedFrameEC[k] = (char)receivedValue[k];
    }
    my_FrameReceived[nbValueToSend].receivedDataTimeEC = simultime;
    nbreceivedValue = k;
    for(m =0;m<=valueVirgule2-k;m++)
    {
            my_FrameReceived[nbValueToSend].receivedFrameTDS[m] = (char)receivedValue[m+nbreceivedValue-1];
    }
    for(int t =0;t<=29;t++)
    {
          receivedValue[t]='\0';
    }
    my_FrameReceived[nbValueToSend].receivedDataTimeTDS = simultime;

    compteID  = 0;
    simultime++;
    nbValueToSend++;
    receivedValueCR = false;
}



