


#include <xc.h>
#include "commun.h"

/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/
char rx;
char rx2;

/* High-priority service */
void interrupt high_isr(void)
{
     /* Determine which flag generated the interrupt */
    if(PIR1bits.RCIF == 1)
    {
        rx = Read1USART();
        buffer1Write ++;
        if(buffer1Write>= 128)
        {
           buffer1Write = 0;
        }
        bufferint1[buffer1Write] = rx;
        PIR1bits.RCIF = 0;
    }

    if(PIR3bits.RC2IF == 1)
    {
        rx2 = Read2USART();
        buffer2Write ++;
        if(buffer2Write>= 128)
        {
           buffer2Write = 0;
        }
        bufferint2[buffer2Write] = rx2;
        PIR3bits.RC2IF = 0; // clear rx2 flag
    }
}
/* Low-priority interrupt routine */
void low_priority interrupt low_isr(void)
{
}
