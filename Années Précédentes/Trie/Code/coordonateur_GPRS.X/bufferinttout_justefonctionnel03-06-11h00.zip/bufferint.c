#include "bufferint.h"

void readbuffer()
{
    char br1 = '\0';
    char br2 = '\0';
    if(buffer1Write != buffer1Read)
    {
        buffer1Read  ++;

        if(buffer1Read>= 128)
        {
           buffer1Read = 0;
        }
        br1 = bufferint1[buffer1Read];
//        while(Busy1USART());
//        Write1USART(bufferint1[buffer1Read]);
        while(Busy2USART());
        Write2USART(br1);
       switch(br1) // valeur ASCII du caractere appuye
        {
            case SOH: // touche DEL
                VSOH = true;
                break;
            case SOL: // touche DEL
                if(VSOH)
                {
                    VSOH = false;
                    VSOok = 1;
                    nbOfChar = 0;
                }
                break;
            default:
                    if(VSOok == 1)
                    {
                        checksumtoChesck = 0;
                        dataLenghtoReceived = (int)br1;
                        VSOok = 2;
                    }
                    else if(VSOok == 2)
                    {
                        dataLenghtoReceived += (int)br1;
                        VSOok = 3;
                    }
                    else if(VSOok == 3)
                    {
                        idReceived = (int)br1;
                        checksumtoChesck = (int)br1;
                        nbOfChar = 0;
                        VSOok = 4;
                    }
                    else if(VSOok == 4)
                    {
                        if(nbOfChar<=dataLenghtoReceived-2)
                        {
                            trameToParse[nbOfChar] = br1;
                            checksumtoChesck += (int)br1;
                        }
                        else
                        {
                            trameToParse[nbOfChar] = br1;
                            checksumtoChesck += (int)br1;
                            VSOok = 5;
                        }
                        //? pas enctrameToParse[nbOfChar] = br1;
                        nbOfChar ++;
                    }
                    else if(VSOok == 5)
                    {

                        ChecksumReceived=br1;
                        VSOok = 6;
                    }
                    else if(VSOok == 6)
                    {
                        ChecksumReceived+=br1;
                        VSOok = 0;

                        if(checksumtoChesck == ChecksumReceived)
                        {
                          //  trameToParse[0] = '\0';
                            VtrameReceived = true;
                        }
                        else
                        {
                            trameToParse[0] = '\0';
                            idReceived = 0;
                            VtrameReceived = false;
                        }

                    }

                break;
        };
    }
    else if(buffer2Write != buffer2Read)
    {
        buffer2Read  ++;
        if(buffer2Read>= 128)
        {
           buffer2Read = 0;
        }
        br2 = bufferint2[buffer2Read];
        while(Busy1USART());
        Write1USART(br2);
        
        if(br2=='K'&&VO)
        {
            br2='\0';
            VOK = true;
            VO = false;
        }
        else if(br2=='O')
        {
            br2='\0';
            VO = true;
        }
        else if(br2=='A'&&VO)
        {
            br2='\0';
            VKA = true;
            VO = false;
        }
        else if(br2 =='D'&&VKA)
        {
            br2='\0';
            VOK = true;
            VO = false;
            VKA = false;
        }
        else if(br2=='e')
        {
            br2='\0';
            Vstarte = true;
        }
        else if(br2=='a'&& Vstarte)
        {
            oR='\0';
            Vstarta = true;
            Vstarte = false;
        }
        else if(br2=='d'&&Vstarta)
        {
            br2='\0';
            Vstartd = true;
            Vstarte = false;
            Vstarta = false;
        }
        else if(br2=='y'&& Vstartd)
        {
            br2='\0';
            VstartReady = true;
            Vstarte = false;
            Vstarta = false;
            Vstartd = false;
        }
        else
        {
            VO = false;
            VKA = false;
            Vstarte = false;
            Vstarta = false;
            Vstartd = false;
            //VOK = false;
        }
    }
}
void executeBuffer()
{
    int w=0;
    if(idReceived == 0x10)
    {
        w=0;
        for(int w=0;w<=4;w++)
        {
            my_FrameReceived[nbFramePH].receivedFramePH[w] = trameToParse[w];
        }
        my_FrameReceived[nbFramePH].receivedDataTimePH[0] = trameToParse[w+1];
        my_FrameReceived[nbFramePH].receivedDataTimePH[1] = trameToParse[w+2];
        nbFramePH ++;
        idReceived = 0;
    }
    else if(idReceived == 0x11)
    {
        w=0;
        for(w=0;w<=4;w++)
        {
            my_FrameReceived[nbFrameDO].receivedFrameDO[w] = trameToParse[w];
        }
        my_FrameReceived[nbFrameDO].receivedDataTimeDO[0] = trameToParse[w+1];
        my_FrameReceived[nbFrameDO].receivedDataTimeDO[1] = trameToParse[w+2];
        nbFrameDO ++;
        idReceived = 0;
    }
    else if(idReceived == 0x12)
    {
        w=0;
        for(w=0;w<=5;w++)
        {
            my_FrameReceived[nbFrameEC].receivedFrameEC[w] = trameToParse[w];
        }
        my_FrameReceived[nbFrameEC].receivedDataTimeEC[0] = trameToParse[w+1];
        my_FrameReceived[nbFrameEC].receivedDataTimeEC[1] = trameToParse[w+2];
        nbFrameEC ++;
        idReceived = 0;
    }
    else if(idReceived == 0x12)
    {
        w=0;
        for(w=0;w<=5;w++)
        {
            my_FrameReceived[nbFrameTDS].receivedFrameTDS[w] = trameToParse[w];
        }
        my_FrameReceived[nbFrameTDS].receivedDataTimeTDS[0] = trameToParse[w+1];
        my_FrameReceived[nbFrameTDS].receivedDataTimeTDS[1] = trameToParse[w+2];
        nbFrameTDS ++;
        idReceived = 0;
    }
    else if(idReceived == 0x21)
    {
        int testtt = 0;
        switch(trameToParse[0]) // valeur ASCII du caractere appuye
        {
            case 'p': // touche DEL
                if(VTest)
                {
                    PORTCbits.RC3 = 1;
                    while(Busy1USART());
                    Write1USART('1');
                    VTest=false;
                }
                else
                {
                    PORTCbits.RC3 = 0;
                    while(Busy1USART());
                    Write1USART('0');
                    VTest=true;
                }
                break;
            case 'g': // touche DEL
                Vg = true;
                VOK = false;
                VPH = false;
                VFC = false;
                break;
            case 'u': // touche DEL
                Vu = true;
                break;
            case 'y': // touche DEL
                Vy = true;
                VOK = false;
                VPH = false;
                VFC = false;
                VPOST = false;
                mcStartGSM = 10;
                mcPostGSM = 0;
                VstartReady = false;
                break;
            case 'r': // touche DEL
                Vr = true;
                break;
//            case 'P': // touche DEL
//                VP = true;
//                break;
//            case 'H': // touche DEL
//                if(VP)
//                {
//                    VP = false;
//                    VPH = true;
//                }
//                break;
//            case 'F': // touche DEL
//                VF = true;
//                break;
//            case 'C': // touche DEL
//                if(VF)
//                {
//                    VF = false;
//                    VFC = true;
//                }
//                break;
//            case 'A': // touche DEL
//                VA = true;
//                break;
//            case 'G': // touche DEL
//                if(VA)
//                {
//                    VA = false;
//                    VAG = true;
//                }
//                break;
//            case 'E': // touche DEL
//                VE = true;
//                break;
//            case 'N': // touche DEL
//                if(VE)
//                {
//                    VE = false;
//                    VN = true;
//                }
//                break;
//            case 'D': // touche DEL
//                if(VN && VAG)
//                {
//                    VN = false;
//                    VAG = false;
//                    VPH = false;
//                    VFC = false;
//                    VD = true;
//                    my_FrameReceivedDO[nbFrame].receivedFrameDO[0]= 'e';
//                    my_FrameReceivedDO[nbFrame].receivedFrameDO[1]= 'n';
//                    my_FrameReceivedDO[nbFrame].receivedFrameDO[2]= 'd';
//                }
//                if(VN && VPH)
//                {
//                    VN = false;
//                    VPH = false;
//                    VFC = false;
//                    VAG = false;
//                    VD = true;
//                    my_FrameReceivedPH[nbFramePH].receivedFramePH[0]= 'e';
//                    my_FrameReceivedPH[nbFramePH].receivedFramePH[1]= 'n';
//                    my_FrameReceivedPH[nbFramePH].receivedFramePH[2]= 'd';
//                }
//                if(VN && VFC)
//                {
//                    VN = false;
//                    VPH = false;
//                    VFC = false;
//                    VAG = false;
//                    VD = true;
//                    my_FrameReceivedEC[nbFrameEC].receivedFrameEC[0]= 'e';
//                    my_FrameReceivedEC[nbFrameEC].receivedFrameEC[1]= 'n';
//                    my_FrameReceivedEC[nbFrameEC].receivedFrameEC[2]= 'd';
//                }
//                break;
//            case '\0': // touche DEL
//                if(VAG)
//                {
//                    nbFrame++;
//                    nbCF = 0;
//                }
//                if(VPH)
//                {
//                    nbFramePH++;
//                    nbCF = 0;
//                }
//                if(VFC)
//                {
//                    nbFrameEC++;
//                    nbCF = 0;
//                }
//                break;
            default:
//                VA = false;
//                VO = false;
//                VP = false;
//                Vg = false;
//                VF = false;
//                if(VAG)
//                {
//                    my_FrameReceivedDO[nbFrame].receivedFrameDO[nbCF]= br1;
//                    nbCF++;
//                }
//                if(VPH)
//                {
//                    my_FrameReceivedPH[nbFramePH].receivedFramePH[nbCF]= br1;
//                    nbCF++;
//                }
//                if(VFC)
//                {
//                    my_FrameReceivedEC[nbFrameEC].receivedFrameEC[nbCF]= br1;
//                    nbCF++;
//                }
                break;

        };

        idReceived = 0;
    }

    

}
