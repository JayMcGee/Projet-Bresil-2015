/* 
 * File:   bufferint.h
 * Author: nitro
 *
 * Created on 29 mai 2014, 09:43
 */

#ifndef BUFFERINT_H
#define	BUFFERINT_H


#include "commun.h"

bool VSOH = false;
bool VSOok= false;
bool VFOH = false;
bool VtrameReceived = false;
int VFOok = 1;
int nbOfChar = 0;
int idReceived = 0;
int checksumtoChesck = 0 ;
int dataLenghtoReceived = 0;
int ChecksumReceived = 0;


unsigned char trameToParse[30];





void readbuffer();
void executeBuffer();

#endif	/* BUFFERINT_H */

